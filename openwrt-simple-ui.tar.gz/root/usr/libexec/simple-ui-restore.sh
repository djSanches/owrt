#!/bin/sh
# Возвращает настройки uhttpd, какими они были до установки панели:
# LuCI снова на стандартном адресе, наша панель остаётся по /simple/.

if [ ! -e /etc/config/uhttpd.bak-simple-ui ]; then
	echo "Резервная копия /etc/config/uhttpd.bak-simple-ui не найдена."
	exit 1
fi

cp /etc/config/uhttpd.bak-simple-ui /etc/config/uhttpd
# /ubus нужен нашей панели, если вы захотите открывать её по /simple/
[ -n "$(uci -q get uhttpd.main.ubus_prefix)" ] || { uci set uhttpd.main.ubus_prefix='/ubus'; uci commit uhttpd; }
/etc/init.d/uhttpd restart

IP="$(uci -q get network.lan.ipaddr | cut -d/ -f1)"
echo "Восстановлено. LuCI: http://$IP/   Панель: http://$IP/simple/"
