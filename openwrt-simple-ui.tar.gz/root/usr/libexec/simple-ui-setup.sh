#!/bin/sh
# Выполняется на роутере после копирования файлов.
# Наша панель становится главной страницей (порт 80/443),
# оригинальный LuCI переезжает на отдельный порт (по умолчанию 8080).

LUCI_PORT="${LUCI_PORT:-8080}"

# Нужен модуль ubus для uhttpd, иначе /ubus недоступен из браузера
if [ ! -e /usr/lib/uhttpd_ubus.so ]; then
	echo "Устанавливаю uhttpd-mod-ubus..."
	if command -v apk >/dev/null 2>&1; then
		apk add uhttpd-mod-ubus
	else
		opkg update && opkg install uhttpd-mod-ubus
	fi
fi

chmod 0644 /www/simple/* /usr/share/rpcd/acl.d/simple-ui.json
chmod 0755 /usr/libexec/simple-ui-restore.sh

# Резервная копия настроек uhttpd (делается один раз)
[ -e /etc/config/uhttpd.bak-simple-ui ] || cp /etc/config/uhttpd /etc/config/uhttpd.bak-simple-ui

# 1. Отдельный экземпляр uhttpd для оригинального LuCI
if ! uci -q get uhttpd.luci >/dev/null; then
	uci set uhttpd.luci=uhttpd
	uci set uhttpd.luci.home='/www'
	uci add_list uhttpd.luci.listen_http="0.0.0.0:$LUCI_PORT"
	uci add_list uhttpd.luci.listen_http="[::]:$LUCI_PORT"
	for o in cgi_prefix rfc1918_filter max_requests max_connections script_timeout network_timeout http_keepalive tcp_keepalive; do
		v=$(uci -q get uhttpd.main.$o) && [ -n "$v" ] && uci set uhttpd.luci.$o="$v"
	done
	for l in lua_prefix ucode_prefix interpreter; do
		for v in $(uci -q get uhttpd.main.$l); do
			uci add_list uhttpd.luci.$l="$v"
		done
	done
	uci set uhttpd.luci.ubus_prefix='/ubus'
fi

# 2. Основной экземпляр отдаёт нашу панель
uci set uhttpd.main.home='/www/simple'
uci set uhttpd.main.ubus_prefix='/ubus'
uci -q delete uhttpd.main.cgi_prefix
uci -q delete uhttpd.main.lua_prefix
uci -q delete uhttpd.main.ucode_prefix
uci -q delete uhttpd.main.index_page
uci commit uhttpd

/etc/init.d/rpcd restart
/etc/init.d/uhttpd restart

IP="$(uci -q get network.lan.ipaddr | cut -d/ -f1)"
echo "Готово."
echo "  Новая панель:    http://$IP/"
echo "  Оригинальный LuCI: http://$IP:$LUCI_PORT/"
echo "Вернуть всё как было: sh /usr/libexec/simple-ui-restore.sh"
