'use strict';
/* Простой веб-интерфейс для OpenWrt. Работает поверх ubus JSON-RPC (/ubus), без LuCI. */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const NOSID = '0'.repeat(32);
let sid = sessionStorage.getItem('sid') || NOSID;
let timer = null;

/* ---------- ubus ---------- */
async function ubus(obj, method, args = {}) {
  const r = await fetch('/ubus', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'call', params: [sid, obj, method, args] })
  });
  const j = await r.json();
  if (j.error) throw new Error(j.error.message || 'Ошибка RPC');
  const [code, data] = j.result;
  if (code === 6 && sid !== NOSID) { logout(); throw new Error('Сессия истекла, войдите снова'); }
  if (code === 6) throw new Error('Доступ запрещён');
  if (code === 4) throw new Error('Не найдено: ' + obj + '.' + method);
  if (code !== 0) throw new Error('Ошибка ubus ' + code);
  return data || {};
}
const uciGet = async c => (await ubus('uci', 'get', { config: c })).values || {};
const uciSet = (c, s, v) => ubus('uci', 'set', { config: c, section: s, values: v });
const uciDel = async (c, s, opts) => { try { await ubus('uci', 'delete', opts ? { config: c, section: s, options: opts } : { config: c, section: s }); } catch (e) { /* нечего удалять */ } };
const uciCommit = c => ubus('uci', 'commit', { config: c });
const exec = (command, params = []) => ubus('file', 'exec', { command, params });

/* ---------- утилиты ---------- */
function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = bad ? 'show bad' : 'show';
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.className = ''; }, 4500);
}
const first = v => Array.isArray(v) ? v[0] : v;
const ip4 = s => /^(\d{1,3}\.){3}\d{1,3}$/.test(s) && s.split('.').every(n => +n < 256);
const portOk = s => /^\d{1,5}(-\d{1,5})?$/.test(s) && s.split('-').every(n => +n >= 1 && +n <= 65535);
function fmtUptime(s) {
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return (d ? d + ' д ' : '') + h + ' ч ' + m + ' мин';
}
const fmtMB = b => (b / 1048576).toFixed(0) + ' МБ';

async function readLeases() {
  try {
    const r = await ubus('file', 'read', { path: '/tmp/dhcp.leases' });
    return (r.data || '').trim().split('\n').filter(Boolean).map(l => {
      const p = l.split(' ');
      return { mac: (p[1] || '').toLowerCase(), ip: p[2] || '', name: p[3] && p[3] !== '*' ? p[3] : '' };
    });
  } catch (e) { return []; }
}
async function wifiMacs() {
  const set = new Set();
  try {
    const devs = (await ubus('iwinfo', 'devices')).devices || [];
    for (const dev of devs) {
      const a = (await ubus('iwinfo', 'assoclist', { device: dev })).results || [];
      a.forEach(x => set.add(String(x.mac).toLowerCase()));
    }
  } catch (e) { /* нет Wi-Fi или нет iwinfo */ }
  return set;
}

/* ---------- вход / выход ---------- */
function showLogin() {
  clearInterval(timer);
  $('#app').classList.add('hidden');
  $('#login').classList.remove('hidden');
  $('#loginPass').focus();
}
function showApp() {
  $('#login').classList.add('hidden');
  $('#app').classList.remove('hidden');
  route();
}
function logout() {
  sessionStorage.removeItem('sid');
  sid = NOSID;
  showLogin();
}
$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  $('#loginErr').textContent = '';
  try {
    sid = NOSID;
    const r = await ubus('session', 'login', { username: 'root', password: $('#loginPass').value, timeout: 3600 });
    sid = r.ubus_rpc_session;
    sessionStorage.setItem('sid', sid);
    $('#loginPass').value = '';
    showApp();
  } catch (err) {
    $('#loginErr').textContent = 'Неверный пароль или роутер недоступен';
  }
});
$('#logoutBtn').onclick = async () => {
  try { await ubus('session', 'destroy', { session: sid }); } catch (e) { /* ignore */ }
  logout();
};

/* ---------- роутинг ---------- */
const pages = { status: pStatus, wifi: pWifi, clients: pClients, network: pNetwork, forward: pForward, system: pSystem };
async function route() {
  clearInterval(timer);
  const name = (location.hash || '#status').slice(1);
  const fn = pages[name] || pStatus;
  $$('#menu nav a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + (pages[name] ? name : 'status')));
  const v = $('#view');
  const tok = v._tok = Symbol();
  const alive = () => v._tok === tok && sid !== NOSID;
  try { await fn(v, alive); }
  catch (e) { if (alive()) v.innerHTML = '<div class="card"><h2>Ошибка</h2><p class="err">' + esc(e.message) + '</p></div>'; }
}
window.addEventListener('hashchange', () => { if (sid !== NOSID) route(); });

/* ---------- Состояние ---------- */
async function pStatus(v, alive) {
  const draw = async () => {
    const [info, board, dump, leases, macs] = await Promise.all([
      ubus('system', 'info'), ubus('system', 'board'), ubus('network.interface', 'dump'), readLeases(), wifiMacs()
    ]);
    if (!alive()) return;
    const ifs = dump.interface || [];
    const wan = ifs.find(i => i.interface === 'wan') || ifs.find(i => (i.route || []).some(r => r.target === '0.0.0.0'));
    const wanIp = wan && (wan['ipv4-address'] || [])[0];
    const gw = wan && (wan.route || []).find(r => r.target === '0.0.0.0');
    const dns = wan ? (wan['dns-server'] || []).join(', ') : '';
    const m = info.memory || {};
    const used = m.total - (m.available ?? m.free);
    v.innerHTML = `
      <h1>Состояние</h1>
      <div class="card">
        <h2><span class="dot ${wan && wan.up ? 'ok' : ''}"></span>Интернет: ${wan && wan.up ? 'подключено' : 'нет соединения'}</h2>
        <div class="grid" style="margin:0">
          <div class="stat"><div class="k">IP-адрес (WAN)</div><div class="v">${esc(wanIp ? wanIp.address : '—')}</div></div>
          <div class="stat"><div class="k">Шлюз</div><div class="v">${esc(gw ? gw.nexthop : '—')}</div></div>
          <div class="stat"><div class="k">DNS</div><div class="v" style="font-size:16px">${esc(dns || '—')}</div></div>
          <div class="stat"><div class="k">Подключено</div><div class="v">${wan && wan.up ? fmtUptime(wan.uptime || 0) : '—'}</div></div>
        </div>
      </div>
      <div class="grid">
        <div class="stat"><div class="k">Устройств в сети</div><div class="v">${leases.length}</div></div>
        <div class="stat"><div class="k">Из них по Wi-Fi</div><div class="v">${macs.size}</div></div>
        <div class="stat"><div class="k">Время работы</div><div class="v">${fmtUptime(info.uptime || 0)}</div></div>
        <div class="stat"><div class="k">Нагрузка CPU</div><div class="v">${(info.load || []).slice(0, 3).map(x => (x / 65535).toFixed(2)).join(' / ')}</div></div>
        <div class="stat"><div class="k">Память</div><div class="v">${fmtMB(used)} / ${fmtMB(m.total)}</div></div>
      </div>
      <div class="card">
        <h2>Устройство</h2>
        <table>
          <tr><th>Модель</th><td>${esc(board.model || board.board_name || '')}</td></tr>
          <tr><th>Прошивка</th><td>${esc((board.release || {}).description || '')}</td></tr>
          <tr><th>Имя хоста</th><td>${esc(board.hostname || '')}</td></tr>
        </table>
      </div>`;
  };
  await draw();
  timer = setInterval(() => draw().catch(() => { }), 5000);
}

/* ---------- Wi-Fi ---------- */
const ENCS = [
  ['psk2', 'WPA2-PSK (рекомендуется)'],
  ['sae-mixed', 'WPA2/WPA3'],
  ['sae', 'WPA3-SAE'],
  ['psk-mixed', 'WPA/WPA2 (устаревшая)'],
  ['none', 'Без пароля (открытая)']
];
async function pWifi(v, alive) {
  const w = await uciGet('wireless');
  const devs = {}, ifs = [];
  for (const s of Object.values(w)) {
    if (s['.type'] === 'wifi-device') devs[s['.name']] = s;
    else if (s['.type'] === 'wifi-iface' && (s.mode || 'ap') === 'ap') ifs.push(s);
  }
  if (!alive()) return;
  if (!ifs.length) { v.innerHTML = '<h1>Wi-Fi</h1><div class="card">Точки доступа не найдены в /etc/config/wireless.</div>'; return; }
  const band = d => {
    const x = devs[d] || {};
    const b = x.band || (x.hwmode === '11a' ? '5g' : '2g');
    return { '2g': '2,4 ГГц', '5g': '5 ГГц', '6g': '6 ГГц', '60g': '60 ГГц' }[b] || b;
  };
  const cards = ifs.map(s => {
    const cur = s.encryption || 'none';
    const known = ENCS.find(e => cur === e[0] || cur.startsWith(e[0] + '+'));
    const norm = known ? known[0] : cur;
    const opts = (known ? ENCS : [[cur, cur]].concat(ENCS))
      .map(e => `<option value="${esc(e[0])}" ${e[0] === norm ? 'selected' : ''}>${esc(e[1])}</option>`).join('');
    return `
      <div class="card wifi" data-sec="${esc(s['.name'])}" data-orig="${esc(cur)}" data-norm="${esc(norm)}">
        <h2>${esc(band(s.device))} <span class="muted">${esc(s.device)}</span></h2>
        <label class="sw"><input type="checkbox" class="f-en" ${s.disabled === '1' ? '' : 'checked'}> Включена</label>
        <label>Имя сети (SSID)<input class="f-ssid" maxlength="32" value="${esc(s.ssid)}"></label>
        <div class="row">
          <label>Защита<select class="f-enc">${opts}</select></label>
          <label>Пароль
            <div class="pw"><input class="f-key" type="password" value="${esc(s.key || '')}" autocomplete="new-password">
              <button type="button" class="btn ghost show">Показать</button></div>
          </label>
        </div>
        <label class="sw"><input type="checkbox" class="f-hid" ${s.hidden === '1' ? 'checked' : ''}> Скрыть имя сети</label>
      </div>`;
  }).join('');
  v.innerHTML = `
    <h1>Wi-Fi</h1>
    ${cards}
    <div class="actions">
      ${ifs.length > 1 ? '<button class="btn" id="copyAll" type="button">Одинаковые имя и пароль на всех сетях</button>' : ''}
      <button class="btn primary" id="save" type="button">Сохранить и применить</button>
    </div>`;

  $$('.show', v).forEach(b => b.onclick = () => {
    const i = $('.f-key', b.closest('.card'));
    i.type = i.type === 'password' ? 'text' : 'password';
    b.textContent = i.type === 'password' ? 'Показать' : 'Скрыть';
  });
  const copyAll = $('#copyAll', v);
  if (copyAll) copyAll.onclick = () => {
    const [c0, ...rest] = $$('.wifi', v);
    rest.forEach(c => {
      $('.f-ssid', c).value = $('.f-ssid', c0).value;
      $('.f-key', c).value = $('.f-key', c0).value;
      const sel = $('.f-enc', c);
      if ([...sel.options].some(o => o.value === $('.f-enc', c0).value)) sel.value = $('.f-enc', c0).value;
    });
    toast('Скопировано. Нажмите «Сохранить и применить».');
  };
  $('#save', v).onclick = async () => {
    const data = [];
    for (const c of $$('.wifi', v)) {
      const ssid = $('.f-ssid', c).value, enc = $('.f-enc', c).value, key = $('.f-key', c).value;
      if (!ssid || new TextEncoder().encode(ssid).length > 32) return toast('Имя сети: от 1 до 32 байт', true);
      if (enc !== 'none' && (key.length < 8 || key.length > 63)) return toast('Пароль сети «' + ssid + '»: от 8 до 63 символов', true);
      const vals = {
        ssid,
        encryption: enc === c.dataset.norm ? c.dataset.orig : enc,
        hidden: $('.f-hid', c).checked ? '1' : '0',
        disabled: $('.f-en', c).checked ? '0' : '1'
      };
      if (enc !== 'none') vals.key = key;
      data.push({ sec: c.dataset.sec, vals });
    }
    if (!confirm('Применить настройки Wi-Fi?\nУстройства придётся подключить заново, если вы меняли имя или пароль.')) return;
    try {
      for (const d of data) await uciSet('wireless', d.sec, d.vals);
      await uciCommit('wireless');
      await exec('/sbin/wifi', ['reload']);
      toast('Сохранено. Wi-Fi перезапускается…');
    } catch (e) { toast('Ошибка: ' + e.message, true); }
  };
}

/* ---------- Устройства ---------- */
async function pClients(v, alive) {
  const [leases, macs] = await Promise.all([readLeases(), wifiMacs()]);
  if (!alive()) return;
  const ipn = s => s.split('.').reduce((a, b) => a * 256 + (+b || 0), 0);
  leases.sort((a, b) => ipn(a.ip) - ipn(b.ip));
  const rows = leases.map(l => `
    <tr><td>${esc(l.name || '—')}</td><td>${esc(l.ip)}</td><td>${esc(l.mac)}</td>
    <td><span class="tag ${macs.has(l.mac) ? 'wifi' : ''}">${macs.has(l.mac) ? 'Wi-Fi' : 'Кабель'}</span></td></tr>`).join('');
  v.innerHTML = `
    <h1>Устройства</h1>
    <div class="card table-wrap">
      <table>
        <tr><th>Имя</th><th>IP-адрес</th><th>MAC-адрес</th><th>Подключение</th></tr>
        ${rows || '<tr><td colspan="4" class="muted">Нет устройств</td></tr>'}
      </table>
    </div>`;
}

/* ---------- Сеть ---------- */
async function pNetwork(v, alive) {
  const [n, d] = await Promise.all([uciGet('network'), uciGet('dhcp')]);
  if (!alive()) return;
  const lan = n.lan, wan = n.wan, dh = d.lan;
  if (!lan) { v.innerHTML = '<h1>Сеть</h1><div class="card">Интерфейс «lan» не найден.</div>'; return; }
  const lanIp = String(first(lan.ipaddr) || '');
  const dns = (Array.isArray(wan && wan.dns) ? wan.dns : (wan && wan.dns ? String(wan.dns).split(/[\s,]+/) : [])).join(' ');
  const proto = wan ? (wan.proto || 'dhcp') : '';
  const protoOpts = [['dhcp', 'Автоматически (DHCP)'], ['pppoe', 'PPPoE'], ['static', 'Статический IP']]
    .map(p => `<option value="${p[0]}" ${p[0] === proto ? 'selected' : ''}>${p[1]}</option>`).join('');
  v.innerHTML = `
    <h1>Сеть</h1>
    <div class="card">
      <h2>Локальная сеть</h2>
      <div class="row">
        <label>IP роутера<input id="lanIp" value="${esc(lanIp)}"></label>
        <label>Маска<input id="lanMask" value="${esc(lan.netmask || '255.255.255.0')}" ${lanIp.includes('/') ? 'disabled' : ''}></label>
      </div>
      <label class="sw"><input type="checkbox" id="dhcpOn" ${dh && dh.ignore === '1' ? '' : 'checked'}> DHCP-сервер включён</label>
      <div class="row">
        <label>Начало диапазона (смещение)<input id="dhStart" type="number" min="1" value="${esc(dh ? dh.start || 100 : 100)}"></label>
        <label>Количество адресов<input id="dhLimit" type="number" min="1" value="${esc(dh ? dh.limit || 150 : 150)}"></label>
        <label>Время аренды<input id="dhLease" value="${esc(dh ? dh.leasetime || '12h' : '12h')}"></label>
      </div>
    </div>
    ${wan ? `
    <div class="card">
      <h2>Подключение к интернету (WAN)</h2>
      <label>Тип подключения<select id="wanProto">${protoOpts}</select></label>
      <div class="pf" data-for="pppoe">
        <div class="row">
          <label>Логин<input id="pppUser" value="${esc(wan.username || '')}" autocomplete="off"></label>
          <label>Пароль<input id="pppPass" type="password" value="${esc(wan.password || '')}" autocomplete="new-password"></label>
        </div>
      </div>
      <div class="pf" data-for="static">
        <div class="row">
          <label>IP-адрес<input id="stIp" value="${esc(String(first(wan.ipaddr) || ''))}"></label>
          <label>Маска<input id="stMask" value="${esc(wan.netmask || '255.255.255.0')}"></label>
          <label>Шлюз<input id="stGw" value="${esc(wan.gateway || '')}"></label>
        </div>
      </div>
      <label>Свои DNS-серверы (через пробел, необязательно)<input id="wanDns" value="${esc(dns)}" placeholder="1.1.1.1 8.8.8.8"></label>
    </div>` : '<div class="card muted">Интерфейс «wan» не найден — настройка интернета недоступна.</div>'}
    <div class="actions"><button class="btn primary" id="save" type="button">Сохранить и применить</button></div>`;

  const sync = () => {
    const p = $('#wanProto', v) ? $('#wanProto', v).value : '';
    $$('.pf', v).forEach(e => e.classList.toggle('hidden', !e.dataset.for.split(' ').includes(p)));
  };
  if ($('#wanProto', v)) { $('#wanProto', v).onchange = sync; sync(); }

  $('#save', v).onclick = async () => {
    const newIp = $('#lanIp', v).value.trim();
    if (!ip4(newIp.split('/')[0])) return toast('Неверный IP-адрес роутера', true);
    if (!newIp.includes('/') && !ip4($('#lanMask', v).value.trim())) return toast('Неверная маска сети', true);
    const lanVals = { ipaddr: Array.isArray(lan.ipaddr) ? [newIp] : newIp };
    if (!newIp.includes('/')) lanVals.netmask = $('#lanMask', v).value.trim();
    const dhVals = {
      start: String($('#dhStart', v).value), limit: String($('#dhLimit', v).value),
      leasetime: $('#dhLease', v).value.trim() || '12h', ignore: $('#dhcpOn', v).checked ? '0' : '1'
    };
    let wanVals = null, wanDel = [];
    if (wan) {
      const p = $('#wanProto', v).value;
      const dnsList = $('#wanDns', v).value.trim().split(/[\s,]+/).filter(Boolean);
      if (dnsList.some(x => !ip4(x))) return toast('Неверный адрес DNS', true);
      wanVals = { proto: p };
      if (p === 'pppoe') {
        if (!$('#pppUser', v).value) return toast('Укажите логин PPPoE', true);
        wanVals.username = $('#pppUser', v).value; wanVals.password = $('#pppPass', v).value;
      }
      if (p === 'static') {
        const a = $('#stIp', v).value.trim(), m = $('#stMask', v).value.trim(), g = $('#stGw', v).value.trim();
        if (!ip4(a) || !ip4(m) || !ip4(g)) return toast('Проверьте IP, маску и шлюз', true);
        wanVals.ipaddr = a; wanVals.netmask = m; wanVals.gateway = g;
      }
      if (dnsList.length) { wanVals.dns = dnsList; if (p !== 'static') wanVals.peerdns = '0'; }
      else wanDel = p === 'static' ? ['dns'] : ['dns', 'peerdns'];
    }
    if (!confirm('Применить сетевые настройки?\nСоединение с роутером может ненадолго прерваться.')) return;
    try {
      await uciSet('network', 'lan', lanVals);
      if (dh) await uciSet('dhcp', 'lan', dhVals);
      if (wan) {
        await uciSet('network', 'wan', wanVals);
        if (wanDel.length) await uciDel('network', 'wan', wanDel);
      }
      await uciCommit('network');
      await uciCommit('dhcp');
      toast('Сохранено. Применяю…');
      const changed = newIp.split('/')[0] !== lanIp.split('/')[0];
      exec('/etc/init.d/dnsmasq', ['reload']).catch(() => { });
      exec('/etc/init.d/network', ['reload']).catch(() => { });
      if (changed) alert('IP роутера изменён. Откройте http://' + newIp.split('/')[0] + '/ после переподключения к сети.');
    } catch (e) { toast('Ошибка: ' + e.message, true); }
  };
}

/* ---------- Проброс портов ---------- */
async function pForward(v, alive) {
  const [f, leases] = await Promise.all([uciGet('firewall'), readLeases()]);
  if (!alive()) return;
  const rules = Object.values(f).filter(s => s['.type'] === 'redirect');
  const rows = rules.map(r => `
    <tr><td>${esc(r.name || r['.name'])}</td><td>${esc(r.proto || 'tcp udp')}</td><td>${esc(r.src_dport || '')}</td>
    <td>${esc(r.dest_ip || '')}:${esc(r.dest_port || r.src_dport || '')}</td>
    <td><button class="btn danger del" data-sec="${esc(r['.name'])}" type="button">Удалить</button></td></tr>`).join('');
  v.innerHTML = `
    <h1>Проброс портов</h1>
    <div class="card table-wrap">
      <table>
        <tr><th>Название</th><th>Протокол</th><th>Внешний порт</th><th>Куда</th><th></th></tr>
        ${rows || '<tr><td colspan="5" class="muted">Правил нет</td></tr>'}
      </table>
    </div>
    <div class="card">
      <h2>Новое правило</h2>
      <div class="row">
        <label>Название<input id="fwName" placeholder="Например, веб-сервер"></label>
        <label>Протокол<select id="fwProto"><option value="tcp udp">TCP + UDP</option><option value="tcp">TCP</option><option value="udp">UDP</option></select></label>
      </div>
      <div class="row">
        <label>Внешний порт<input id="fwExt" placeholder="80 или 5000-5010"></label>
        <label>IP устройства<input id="fwIp" list="leaseList" placeholder="192.168.1.50"></label>
        <label>Внутренний порт<input id="fwInt" placeholder="как внешний"></label>
      </div>
      <datalist id="leaseList">${leases.map(l => `<option value="${esc(l.ip)}">${esc(l.name)}</option>`).join('')}</datalist>
      <button class="btn primary" id="fwAdd" type="button">Добавить</button>
    </div>`;
  const apply = async () => { await uciCommit('firewall'); await exec('/etc/init.d/firewall', ['reload']); };
  $('#fwAdd', v).onclick = async () => {
    const name = $('#fwName', v).value.trim() || 'redirect';
    const ext = $('#fwExt', v).value.trim(), ip = $('#fwIp', v).value.trim(), int = $('#fwInt', v).value.trim();
    if (!portOk(ext)) return toast('Неверный внешний порт', true);
    if (!ip4(ip)) return toast('Неверный IP устройства', true);
    if (int && !portOk(int)) return toast('Неверный внутренний порт', true);
    const values = { name, src: 'wan', dest: 'lan', proto: $('#fwProto', v).value, src_dport: ext, dest_ip: ip, target: 'DNAT' };
    if (int) values.dest_port = int;
    try { await ubus('uci', 'add', { config: 'firewall', type: 'redirect', values }); await apply(); toast('Правило добавлено'); route(); }
    catch (e) { toast('Ошибка: ' + e.message, true); }
  };
  $$('.del', v).forEach(b => b.onclick = async () => {
    if (!confirm('Удалить правило?')) return;
    try { await uciDel('firewall', b.dataset.sec); await apply(); toast('Правило удалено'); route(); }
    catch (e) { toast('Ошибка: ' + e.message, true); }
  });
}

/* ---------- Система ---------- */
async function pSystem(v, alive) {
  if (!alive()) return;
  v.innerHTML = `
    <h1>Система</h1>
    <div class="card">
      <h2>Пароль администратора</h2>
      <div class="row">
        <label>Новый пароль<input id="p1" type="password" autocomplete="new-password"></label>
        <label>Повторите пароль<input id="p2" type="password" autocomplete="new-password"></label>
      </div>
      <button class="btn primary" id="pwSave" type="button">Сменить пароль</button>
    </div>
    <div class="card">
      <h2>Перезагрузка</h2>
      <p class="muted">Роутер будет недоступен около минуты.</p>
      <button class="btn danger" id="reboot" type="button">Перезагрузить роутер</button>
    </div>`;
  $('#pwSave', v).onclick = async () => {
    const p1 = $('#p1', v).value, p2 = $('#p2', v).value;
    if (p1.length < 6) return toast('Пароль не короче 6 символов', true);
    if (p1 !== p2) return toast('Пароли не совпадают', true);
    try {
      await ubus('luci', 'setPassword', { username: 'root', password: p1 });
      $('#p1', v).value = $('#p2', v).value = '';
      toast('Пароль изменён');
    } catch (e) {
      toast('Не удалось: ' + e.message + ' (нужен пакет luci-base или rpcd-mod-luci)', true);
    }
  };
  $('#reboot', v).onclick = async () => {
    if (!confirm('Перезагрузить роутер?')) return;
    try { await ubus('system', 'reboot'); toast('Роутер перезагружается…'); }
    catch (e) { toast('Ошибка: ' + e.message, true); }
  };
}

/* ---------- старт ---------- */
(async () => {
  if (sid !== NOSID) {
    try { await ubus('system', 'board'); showApp(); return; } catch (e) { /* сессия недействительна */ }
  }
  showLogin();
})();
