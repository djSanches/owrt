#!/bin/sh
# Установка простого интерфейса на роутер OpenWrt по SSH.
# Наша панель будет на главном адресе, оригинальный LuCI уедет на отдельный порт.
#
# Использование: ./install.sh [адрес_роутера] [порт_для_LuCI]
# По умолчанию:  ./install.sh 192.168.1.1 8080
set -e
HOST="${1:-192.168.1.1}"
PORT="${2:-8080}"
DIR="$(cd "$(dirname "$0")" && pwd)"

case "$PORT" in
	''|*[!0-9]*) echo "Порт должен быть числом"; exit 1 ;;
esac

echo "Копирую файлы на root@$HOST ..."
tar -C "$DIR/root" -czf - . | ssh "root@$HOST" "tar -xzf - -C / && LUCI_PORT=$PORT sh /usr/libexec/simple-ui-setup.sh"
